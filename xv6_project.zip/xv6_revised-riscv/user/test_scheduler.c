#include "kernel/types.h"
#include "user/user.h"

int
main(int count, char *args[])
{
  int share;

  if (count < 2) {
    printf("Syntax: test_scheduler [ticket_count]\n");
    exit(1);
  }

  share = atoi(args[1]);

  if (settickets(share) == -1) {
    printf("Failed to assign tickets.\n");
    exit(1);
  }
  for(;;) {
  }

  return 0;
}
